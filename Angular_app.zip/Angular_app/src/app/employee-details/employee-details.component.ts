import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Employee } from 'src/model/employee';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {
  model: Employee = {};
  employeeForm: FormGroup;
  employeeList: Employee[] = [];
  constructor(private _fb: FormBuilder) { }

  ngOnInit(): void {
    this.employeeForm = this._fb.group({
      firstname: [this.model.firstname, Validators.required],
      lastname: [this.model.lastname, Validators.required],
      department: [this.model.department, Validators.required],
      designation: [this.model.designation, Validators.required],
      city: [this.model.city, Validators.required],
    })
  }

  onSave() {
    this.model = this.employeeForm.getRawValue();
    this.employeeList.push(this.model);
  }

}
