import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  model:any={email:'',password:''};
  loginForm:FormGroup;
  constructor(
    private _fb: FormBuilder,
    private router:Router){
  }

  ngOnInit(){
    this.loginForm = this._fb.group({
      email: [this.model.email,Validators.required],
      password: [this.model.password,Validators.required],
    });
  }

  onSubmit(){
    this.model = this.loginForm.getRawValue();    
    console.log(this.model.email,this.model.password);
    this.router.navigate(['employee']);
  }
}
