
export class Employee {
    firstname?: string;
    lastname?: string;
    department?: string;
    designation?: string;
    city?: string
}